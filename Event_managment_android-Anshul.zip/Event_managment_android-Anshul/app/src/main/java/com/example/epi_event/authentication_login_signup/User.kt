package com.example.epi_event.authentication_login_signup

data class User(
    val email: String? = null,
    val userName: String? = null,
    val epitaEmail: String? = null,
){

}
