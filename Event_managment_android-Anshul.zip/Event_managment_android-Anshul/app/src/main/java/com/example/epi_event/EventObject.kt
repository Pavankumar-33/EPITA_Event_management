package com.example.epi_event

data class EventObject(
    val eventName: String? = null,
    val eventPreRegister: String? = null,
    val eventDate: String? = null,
    val eventTime: String? = null,
    val eventLocation: String? = null,

    )
